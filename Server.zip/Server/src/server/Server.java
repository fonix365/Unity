package server;

import java.io.*;
import java.net.*;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class Server {
    private ServerSocket serverSocket = null;
    private int port;
    private List<ClientHandler> clients = new ArrayList<ClientHandler>();
    private List<User> users = new ArrayList<User>();
    private Authentication authentication;
    private Map<String, CommandHandler> commands;

    private static final boolean USER_PREFIX = false;

    public Server(int port) {
        this.port = port;
        this.authentication = new Authentication(this);
        this.commands = new HashMap<>();
    }

    public Authentication authentication() {
      return authentication;
    }

    public List<ClientHandler> connectedClients() {
      return clients;
    }

    public List<User> users() {
      return users;
    }

    public List<User> onlineUsers() {
      List<User> onlineUsers = new ArrayList<User>();
      for (ClientHandler client: clients) {
        onlineUsers.add(client.user());
      }
      return onlineUsers;
    }

    public List<User> offlineUsers() {
      List<User> offlineUsers = new ArrayList<User>();
      for (User user: users) {
        if(!isUserConnected(user.username()))
          offlineUsers.add(user);
      }
      return offlineUsers;
    }

    public Map<String, CommandHandler> commands() {
      return commands;
    }

    public void addUser(User user) {
      users.add(user);
      System.out.println("User " + user.username() + " added to users list.");
    }

    public void printUsers() {
      System.out.println("Users:");
      for(User user: users) {
        System.out.println("\t" + user.username());
      }
    }

    public void printClients() {
      System.out.println("Clients:");
      for(User user: onlineUsers()) {
        System.out.println("\t" + user.username());
      }
    }

    public boolean isUser(String username) {
      for(User user: users) {
        if (user.username().equals(username)) return true;
      }
      return false;
    }

    public User getUser(String username) {
      for(User user: users) {
        if (user.username().equals(username)) return user;
      }
      return null;
    }

    public boolean isUserConnected(String username) {
      for(ClientHandler client : clients) {
        if (client.user().username().equals(username)) return true;
      }
      return false;
    }

    public ClientHandler getClient(String username) {
      for(ClientHandler client : clients) {
        if (client.user().username().equals(username)) return client;
      }
      return null;
    }

    public void addClient(ClientHandler client) {
      clients.add(client);
      System.out.println("Client " + client.user().username() + " added to clients list.");
    }

    public void removeClient(ClientHandler client) {
      clients.remove(client);
      System.out.println("Client " + client.user().username() + " removed from clients list.");
    }

    public void disconnectClients() {
      for (ClientHandler client: clients)
        client.disconnect();
    }

    public void register(String command, CommandHandler handler) {
      command = command.replaceAll("\\s+", "");
      commands.put(command.toLowerCase(), handler);
    }

    public void initCommands() {
      register("Show", new Show());
      register("Send", new Send());
      register("Unicast", new Unicast());
      register("Broadcast", new Broadcast());
    }

    public void initUsers() {
      authentication().initUsers();
      printUsers();
    }

    public void init() {
      initCommands();
      initUsers();
    }

    public void start() {
        try {
            serverSocket = new ServerSocket(port);
            System.out.println("Server started at port " + port);
        }
        catch (IOException e) {
            System.out.println("Error binding serverSocket to port " + port);
            //System.out.println(e);
        }
    }

    public void close() {
      try {
        if (serverSocket != null) serverSocket.close();
      } catch(IOException e) {
        System.out.println("Error closing server socket!");
      }
    }

    public void stop() {
      disconnectClients();
      close();
      System.out.println("Stoping server..");
    }

    public void run() {
        while(true) {
            try {
                System.out.println("Waiting for client ...");
                ClientHandler client = new ClientHandler(this, serverSocket.accept());
                client.open();
                client.init();
                client.start();
                addClient(client);
                System.out.println("User " + client.user().username() + " connected.");
            } catch(IOException e) {
                System.out.println("Error accepting client");
                stop();
            }
        }
    }

    /*public void broadcast(String message) {
      for (ClientHandler client: clients)
        client.sendStringln(message);
    }*/

    public void broadcast(ClientHandler sender, String message) {
      broadcast(sender, message, USER_PREFIX);
    }

    public void broadcast(ClientHandler sender, String message, boolean userPrefix) {
      for (ClientHandler client: clients) {
        if (client == sender) continue;
        else {
          client.sendStringln("\tUser " + sender.user().username() + " sent: " + message);
          if (userPrefix)
            client.sendString(client.user().username() + "$ ");
        }
      }
    }

    public void unicast(ClientHandler sender, ClientHandler receiver, String message) {
      unicast(sender, receiver, message, USER_PREFIX);
    }

    public void unicast(ClientHandler sender, ClientHandler receiver, String message, boolean userPrefix) {
      receiver.sendStringln("\tUser " + sender.user().username() + " sent: " + message);
      if (userPrefix)
        receiver.sendString(receiver.user().username() + "$ ");
    }

    public void sendMessage(Message message) {
      message.receiver().addMessage(message);
    }

    public static void main(String args[]) {
        Server server = new Server(Integer.parseInt(args[0]));
        server.init();
        server.start();
        server.run();
    }
}
