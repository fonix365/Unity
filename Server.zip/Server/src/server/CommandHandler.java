package server;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

public interface CommandHandler {

	/**
	 * @param args A list of string representing the arguments passed to command execution
	 * @param out Channel to write responses to client.
	 * @throws IOException If an error occurs while writing the response.
	 */
	void execute(String[] args, ClientHandler client, Server server) throws IOException;

	void help(ClientHandler client);
}
