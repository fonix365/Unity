package server;

import java.util.Date;

public class Message {
  private Date sent;
  private Date received;
  private String message;
  private User sender;
  private User receiver;

  public Message(User sender, User receiver, String message) {
    this.sent = new Date();
    this.sender = sender;
    this.receiver = receiver;
    this.message = message;
  }

  public void received() {
    this.received = new Date();
  }

  public boolean wasReceived() {
    if (received == null) return false;
    else return true;
  }

  public String getMessage() {
    return message;
  }

  public User sender() {
    return sender;
  }

  public User receiver() {
    return receiver;
  }

  public void printMessage() {
    System.out.print("\tFrom: " + sender.username() + "\n"
                        + "\tTo: " + receiver.username() + "\n"
                        + "\tMessage: " + message + "\n"
                        + "\tSent: " + sent + "\n"
                        + "\tReceived: " + received + "\n");

  }

  public String getPrintMessage() {
    String string = ("\tFrom: " + sender.username() + "\n"
                        + "\tTo: " + receiver.username() + "\n"
                        + "\tMessage: " + message + "\n"
                        + "\tSent: " + sent + "\n");
                        //+ "Received: " + received + "\n");
   return string;
  }
}
