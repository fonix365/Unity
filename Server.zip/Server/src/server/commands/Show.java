package server;

import java.io.IOException;
import java.util.Arrays;

public class Show implements CommandHandler {
  private static final String UNKNOW_ARGUMENT_PREFIX = "Unknown argument ";
  private static final String TOO_MANY_ARGUMENTS = "Too many arguments!";

  private static final String HELP = "\t  show [arg] -> lists the specified argument\n";
  private static final String HELP_USER = "\t    user(s) [arg] -> lists the server users\n";
  private static final String HELP_USER_ARGS = ("\t      no argument -> lists all users\n" +
                                                "\t      online -> lists online users\n" +
                                                "\t      offline -> lists offline users\n");
  private static final String HELP_MESSAGE = "\t    message(s) [arg] -> lists the user messages\n";
  private static final String HELP_MESSAGE_ARGS = ("\t      no argument -> displays the number of new messages\n" +
                                                   "\t      new -> lists new messages\n" +
                                                   "\t      all -> lists all messages\n");

  String firstArg;
  String secondArg;

  @Override
  public void help(ClientHandler client) {
    client.sendString(HELP);
    client.sendString(HELP_USER);
    client.sendString(HELP_USER_ARGS);
    client.sendString(HELP_MESSAGE);
    client.sendString(HELP_MESSAGE_ARGS);
  }

  @Override
  public void execute(String[] args, ClientHandler client, Server server) throws IOException {
    if (args[0] != null) {
      firstArg = new String(args[0].toLowerCase());
      switch (firstArg) {
        case "user":
        case "users":
          if(args.length < 2) {
            client.sendStringln("Users:");
            client.listUsers(server.users());
          }
          else if(args[1] != null && args.length < 3) {
            secondArg = new String(args[1].toLowerCase());
            switch(secondArg) {
              case "online":
                client.sendStringln("Online Users:");
                client.listUsers(server.onlineUsers());
                break;
              case "offline":
                client.sendStringln("Offline Users:");
                client.listUsers(server.offlineUsers());
                break;
              default:
                client.sendStringln("\t" + UNKNOW_ARGUMENT_PREFIX + secondArg);
                client.sendString(HELP_USER);
                client.sendString(HELP_USER_ARGS);
                break;
              }
          }
          else {
            client.sendStringln("\t" + TOO_MANY_ARGUMENTS);
            client.sendString(HELP_USER);
            client.sendString(HELP_USER_ARGS);
          }
          break;
        case "message":
        case "messages":
          if(args.length < 2) {
            client.sendStringln("\tYou have " + client.user().newMessages() + " New Message(s)");
          }
          else if (args[1] != null && args.length < 3) {
            secondArg = new String(args[1].toLowerCase());
            switch(secondArg) {
              case "new":
                client.sendStringln("\t" + client.user().newMessages() + " New Message(s):");
                client.listMessages(client.user().newMessagesList());
                client.user().readAll();
                break;
              case "all":
                client.sendStringln("\t" + client.user().messagesNumber() + " Message(s)");
                client.listMessages(client.user().messages());
                break;
              default:
                client.sendStringln("\t" + UNKNOW_ARGUMENT_PREFIX + secondArg);
                client.sendString(HELP_MESSAGE);
                client.sendString(HELP_MESSAGE_ARGS);
                break;
            }
          }
          else {
            client.sendStringln("\t" + TOO_MANY_ARGUMENTS);
            client.sendString(HELP_MESSAGE);
            client.sendString(HELP_MESSAGE_ARGS);
          }
          break;
        default:
          client.sendStringln("\t" + UNKNOW_ARGUMENT_PREFIX + firstArg);
          help(client);
          break;
      }
    }
  }
}
