package server;

import java.io.IOException;
import java.util.Arrays;
import java.lang.StringBuilder;

public class Broadcast implements CommandHandler {
  private String message;

  @Override
  public void help(ClientHandler client) {
    client.sendString("\t  broadcast [message] -> sends a [message] to all online users\n");
  }

  @Override
  public void execute(String[] args, ClientHandler client, Server server) throws IOException {
    StringBuilder stringBuilder = new StringBuilder();
    for (int i = 0; i < args.length; i ++) {
      stringBuilder.append(args[i] + " ");
    }
    message = stringBuilder.toString();
    server.broadcast(client, message, true);
  }
}
