package server;

import java.io.IOException;
import java.util.Arrays;
import java.lang.StringBuilder;

public class Send implements CommandHandler {
  private String receiver;
  private String message;

  @Override
  public void help(ClientHandler client) {
    client.sendString("\t  send [user] [message] -> sends a [message] to the online or offline specified [user]\n");
  }

  @Override
  public void execute(String[] args, ClientHandler client, Server server) {
    //System.out.println(args.length);
    receiver = args[0];
    if (server.isUser(receiver)) {
      if (args.length > 1) {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 1; i < args.length; i++) {
          stringBuilder.append(args[i] + " ");
        }
        message = stringBuilder.toString();
        server.sendMessage(new Message(client.user(), server.getUser(receiver), message));
      } else client.sendStringln("\tEmpty message!");
    } else
        client.sendStringln("\t" + receiver + " is not a valid user. Please check the list of users");
  }
}
