package server;

import java.io.IOException;
import java.util.Arrays;
import java.lang.StringBuilder;

public class Unicast implements CommandHandler {
  private String receiver;
  private String message;

  @Override
  public void help(ClientHandler client) {
    client.sendString("\t  unicast [user] [message] -> sends a [message] to the online specified [user]\n");
  }

  @Override
  public void execute(String[] args, ClientHandler client, Server server) throws IOException {
    receiver = args[0];
    if (server.isUser(receiver)) {
      if (server.isUserConnected(receiver)) {
        if (args.length > 1) {
          StringBuilder stringBuilder = new StringBuilder();
          for (int i = 1; i < args.length; i++) {
            stringBuilder.append(args[i] + " ");
          }
          message = stringBuilder.toString();
          server.unicast(client, server.getClient(receiver), message, true);
        } else client.sendStringln("\tEmpty message!");
      } else client.sendStringln("\t" + receiver + " is offline.");
    } else client.sendStringln("\t" + receiver + " is not a valid user. Please check the list of users");
  }
}
