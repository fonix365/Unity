package server;

import java.io.*;
import java.net.*;
import java.util.Map;
import java.util.Arrays;
import java.util.List;

public class ClientHandler extends Thread {
  private Server server;

  //private int id;
  private User user;

  private String address;
  private int port;

  private Socket connection;
  private OutputStream output;
  private BufferedReader input;

  private Map<String, CommandHandler> commands;
	private static final String EXIT_CMD = "exit";
	private static final String HELP_CMD = "help";
	private static final String PREFIX_CUSTOM_CMD = "do";
  private static final String UNKNOWN_COMMAND_PREFIX = "Unknown command";

  private static final String DEFAULT_STRINGLN = " ";
  private static final String NO_ARGS = "No arguments provided";
  private static final String HELP_MSG = "If you want a list of supported server functions type help.";

  private static final String CLIENT_HANDLER = "Client Handler: ";

  public ClientHandler(Server server) {
    this.server = server;
    this.commands = server.commands();
    this.connection = null;
  }

  public ClientHandler(Server server, String address, int port) {
    this.server = server;
    this.commands = server.commands();
    this.address = address;
    this.port = port;
  }

  public ClientHandler(Server server, Socket socket) {
    this.server = server;
    this.commands = server.commands();
    this.connection = socket;
    this.address = socket.getRemoteSocketAddress().toString();
    this.port = socket.getPort();
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public void setPort(int port) {
    this.port = port;
  }

  public void setServer(Server server) {
    this.server = server;
  }

  public void setSocket(Socket socket) {
    this.connection = socket;
    setAddress(socket.getRemoteSocketAddress().toString());
    setPort(socket.getPort());
  }

  public void printConnection() {
    System.out.println("Address: " + address);
    System.out.println("Port: " + port);
  }

  public User user() {
    return user;
  }

  public void listUsers(List<User> users) {
    for (User user: users)
      sendStringln("\t  " + user.username());
  }

  public void listMessages(List<Message> messagesList) {
    for (Message message: messagesList) {
      sendString(message.getPrintMessage());
    }
  }

  public void help() {
    sendStringln("\tdo [command] [args] -> execute [command] with specified [args].");
    sendStringln("\thelp do -> list all available [commands] for function 'do'");
    sendStringln("\texit -> disconnect from server.");
  }

  public void commandsHelp() {
    sendStringln("\tdo [command] [args] -> execute [command] with specified [args].");
    for (CommandHandler command : commands.values())
      command.help(this);
  }

  public boolean connect() {
    try {
      connection = new Socket(address, port);
      System.out.println("Socket connected to: " + address + ":" + port);
      return true;
    } catch(IOException e) {
      System.out.println("Error connecting socket to: " + address + ":" + port);
      return false;
    }
  }

  public boolean disconnect() {
    if (close() && closeSocket()) {
      server.removeClient(this);
      return true;
    } else return false;
  }

  public boolean open() {
    System.out.println(CLIENT_HANDLER);
    try {
      output = connection.getOutputStream();
      System.out.println("\tOutput stream open");
      input = new BufferedReader(new InputStreamReader(connection.getInputStream()));
      System.out.println("\tInput stream open");
      return true;
    } catch(IOException e) {
      System.out.println("\tError opening streams");
      return false;
    }
  }

  public boolean close() {
    System.out.println(CLIENT_HANDLER);
    try {
      if (output != null) output.close();
      System.out.println("\tOutput stream closed");
      if (input != null) input.close();
      System.out.println("\tInput stream closed");
      return true;
    } catch(IOException e) {
      System.out.println("\tError closing streams");
      return false;
    }
  }

  public boolean closeSocket() {
    System.out.println(CLIENT_HANDLER);
    try {
      if (connection != null) connection.close();
      System.out.println("\tSocket closed");
      return true;
    } catch(IOException e) {
      System.out.println("\tError closing socket");
      return false;
    }
  }

  public boolean sendString(String string) {
    try {
      output.write(string.getBytes());
      output.flush();
      return true;
    } catch(IOException e) {
      return false;
    }
  }

  public void sendStringln() {
    sendStringln(DEFAULT_STRINGLN);
  }

  public boolean sendStringln(String string) {
    try {
      string = string + "\n";
      output.write(string.getBytes());
      output.flush();
      return true;
    } catch (IOException e) {
      return false;
    }
  }

  public void init() {
    try {
      boolean finish = false;
      sendStringln("       _____________________");
      sendStringln("      |                     |");
      sendStringln("      |      WELCOME!!      |");
      sendStringln("      |                     |");
      sendStringln("      |  Choose an option:  |");
      sendStringln("      |  1) Login           |" );
      sendStringln("      |  2) Register        |");
      sendStringln("      |_____________________|");
      sendStringln();
      while(!finish) {
        sendString("     Option: ");
        String option = input.readLine();
        if (option == null || option.length() == 0) continue;
        if (option.equals("1")) {
            authenticate();
            finish = true;
        }
        else if (option.equals("2")) {
          register();
          finish = true;
        }
        else sendString("Unrecognized option. Please choose 1 for Login or 2 for Register\n");
      }
    } catch(IOException e) {

    }
  }

  public void register() {
    try {
      boolean regist = false;
      sendString("Register\n");
      while(!regist) {
        sendString("Enter username: ");
        String username = input.readLine();
        if (username == null || username.length() == 0) continue;
        sendString("Enter password: ");
        String password = input.readLine();
        if (password == null || password.length() == 0) continue;
        if (!server.isUser(username)) {
          user = server.authentication().register(username, password);
          server.addUser(user);
          sendString("Registration successfull!\n");
          sendStringln("Welcome " + user.username() + "!");
          regist = true;
        }
        else sendString("Username is already in use. Please choose another username.\n");
      }
    } catch(IOException e) {
      System.out.println(e);
    }
  }

  public void authenticate() {
    try {
      boolean auth = false;
      sendString("Login\n");
      while(!auth) {
        sendString("Enter username: ");
        String username = input.readLine();
        if (username == null || username.length() == 0) continue;
        sendString("Enter password: ");
        String password = input.readLine();
        if (password == null || password.length() == 0) continue;
        if (server.authentication().authenticate(username, password)) {
         user = server.getUser(username);
         //System.out.println(user.username());
         //System.out.println(user.password());
         sendString("Authentication successfull!\n");
         sendStringln("Welcome back " + user.username() + "!");
         auth = true;
        }
        else sendString("Username or password incorrect. Please try again.\n");
      }
    } catch(IOException e) {
      System.out.println(e);
    }
  }

  public void run() {
    boolean active = true;
    try {
      while(active) {
        sendString(user().username() + "$ ");
        String inputLine = input.readLine();
        if (inputLine == null || inputLine.length() == 0) continue;
        inputLine = inputLine.trim();
        String[] inputArgs = inputLine.split("\\s{1,}");
        if (inputArgs.length > 0) {
          String command = inputArgs[0].toLowerCase();
          switch (command) {
						case PREFIX_CUSTOM_CMD:
							if(inputArgs.length > 1) {
								processCommand(inputArgs[1], Arrays.copyOfRange(inputArgs, 2, inputArgs.length));
							}
							break;
						case EXIT_CMD:
						  disconnect();
              break;
            case HELP_CMD:
              if(inputArgs.length < 2) {
                help();
              }
              else if (inputArgs[1] != null && inputArgs.length < 3) {
                switch(inputArgs[1]) {
                  case "do":
                    commandsHelp();
                    break;
                  default:
                    sendStringln("\t" + "Unknown argument for function help.");
                    break;
                }
              }
              else {
                sendStringln("\t" + "Too many arguments provided for function help.");
              }
              break;
            default:
              sendString("\t" + UNKNOWN_COMMAND_PREFIX + "\n");
              sendStringln("\t" + HELP_MSG);
					}
        }
      }
    } catch(IOException e) {
      active = false;
    }
  }

  private void processCommand(String command, String[] args) throws IOException {
		CommandHandler handler = commands.get(command);
    if (args.length < 1) {
      sendStringln("\t" + NO_ARGS);
    } else {
      if (handler != null) {
  			handler.execute(args, this, server);
  		} else {
  			sendStringln("\t" + UNKNOWN_COMMAND_PREFIX + command);
  		}
    }

	}
}
