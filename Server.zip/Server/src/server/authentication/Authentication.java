package server;

import java.io.*;
import java.lang.String;
import java.util.List;

public class Authentication {
  private Server server;

  public Authentication(Server server) {
    this.server = server;
  }

  public void initUsers() {
    BufferedReader inReader = null;
    String line;
    String args[];
    String user;
    String pass;
    try {
      inReader = new BufferedReader(new FileReader("authentication.txt"));
      while((line = inReader.readLine()) != null) {
        args = line.split("#");
        user = new String(args[0]);
        pass = new String(args[1]);
        server.addUser(new User(user, pass));
      }
    } catch(IOException e) {

    }
  }

  public boolean authenticate(String username, String password) {
    BufferedReader inReader = null;
    String args[];
    String user;
    String pass;
    try {
      inReader = new BufferedReader(new FileReader("authentication.txt"));
      String line;
      while ((line = inReader.readLine()) != null) {
        args = line.split("#");
        user = new String(args[0]);
        pass = new String(args[1]);
        if (user.equals(username)) {
          if(pass.equals(password)) {
            return true;
          }
        }
      }
    } catch (IOException e) {
      System.out.println(e);
    }
    return false;
  }

  public User register(String username, String password) {
    BufferedWriter outWriter = null;
    try {
      outWriter = new BufferedWriter(new FileWriter("authentication.txt", true));
      outWriter.write(username + "#" + password);
      outWriter.newLine();
      outWriter.flush();
    } catch(IOException e) {
      e.printStackTrace();
    } finally {
      if (outWriter != null) {
        try {
          outWriter.close();
        } catch(IOException e2) {

        }
      }
      User user = new User(username);
      user.setPassword(password);
      server.addUser(user);
      return user;
    }
  }

  public boolean isUser(String username) {
    try {
      BufferedReader inReader = new BufferedReader(new FileReader("authentication.txt"));
      String line = inReader.readLine();
      while (line != null) {
        String[] args = line.split("#");
        String user = args[0];
        if (user.equals(username)) return true;
      }
    } catch (IOException e) {
      System.out.println(e);
    }
    return false;
  }
}
