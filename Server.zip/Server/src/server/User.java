package server;

import java.util.List;
import java.util.ArrayList;

public class User {
  private String username;
  private String password;
  private List<Message> messages;

  public User(User user) {
    this.username = user.username;
    this.password = user.password;
    this.messages = user.messages;
  }

  public User(String username) {
    this.username = username;
    this.messages = new ArrayList<Message>();
  }

  public User(String username, String password) {
    this.username = username;
    this.password = password;
    this.messages = new ArrayList<Message>();
  }

  public void setPassword(String password) {
    this.password = password;
  }

  public String username() {
    return username;
  }

  public String password() {
    return password;
  }

  public List<Message> messages() {
    return messages;
  }

  public int messagesNumber() {
    return messages.size();
  }

  public void addMessage(Message message) {
    messages.add(message);
  }

  public List<Message> newMessagesList() {
    List<Message> newMessages = new ArrayList<Message>();
    for (Message message: messages)
      if (!message.wasReceived())
        newMessages.add(message);
    return newMessages;
  }

  public int newMessages() {
    int i = 0;
    for(Message message : messages) {
      if(!message.wasReceived()) i++;
    }
    return i;
  }

  public void readAll() {
    for (Message message: messages) {
      if (!message.wasReceived())
        message.received();
    }
  }
}
