java -jar Server.jar [port]
